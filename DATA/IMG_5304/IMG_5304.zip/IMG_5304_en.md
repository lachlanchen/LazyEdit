- [ ] <-- Mark if you are done editing.

<video controls="true" allowfullscreen="true"> <source src="IMG_5304_en.MOV" type="video/MOV"> </video>


Texts generated from [IMG_5304_en.srt](IMG_5304_en.srt).Mark the sentences to keep for autocut.
The format is [subtitle_index,duration_in_second] subtitle context.


- [ ] [1,00:00]   The only good thing about this is the chicken. It's really good.
- [ ] [2,00:03]   Very tender.
- [ ] [3,00:05]   Really good.