- [ ] <-- Mark if you are done editing.

<video controls="true" allowfullscreen="true"> <source src="IMG_5304_zh.MOV" type="video/MOV"> </video>


Texts generated from [IMG_5304_zh.srt](IMG_5304_zh.srt).Mark the sentences to keep for autocut.
The format is [subtitle_index,duration_in_second] subtitle context.


- [ ] [1,00:00]   这个唯一好吃的是这个鸡肉挺好吃的
- [ ] [2,00:02]   特别好吃
- [ ] [3,00:03]   很嫩
- [ ] [4,00:04]   太好吃了